# "PROJECT:墨 (SUMI)" - Final Japanese Indie Edition
# Developed by Arena Strategic Agent

define s = Character(" ", color="#000000", who_outlines=[(2, "#ffffff")])
define p = Character("...", color="#ffffff")

# Эффекты
init python:
    def ink_glitch(st, at):
        if store.resonance > 70:
            return Text("{font=gui/font.ttf}{size=40}ОШИБКА РЕЗОНАНСА{/size}{/font}"), 0.1
        return Null(), 100.0

# Переменные
default ink_level = 50
default resonance = 0
default seen_truth = False

label start:
    scene bg white
    play music "audio/atmospheric_drone_highres.wav" loop fadein 3.0
    
    "Оно пахло сыростью и старой бумагой."
    "Оно не имело лица, но я чувствовал, как оно смотрит на меня."
    
    show monster_ink at center with dissolve
    
    label choice_loop:
        if resonance > 80:
            scene bg white
            show monster_ink at truecenter with hpunch
            s "{size=60}Т Ы   В И Д И Ш Ь   М Е Н Я ?{/size}"
            menu:
                "Да":
                    $ seen_truth = True
                    jump end_transcendence
                "Нет":
                    $ resonance -= 20
                    jump choice_loop

        menu:
            "Протянуть руку к тени":
                $ resonance += 15
                $ ink_level += 5
                "Чернила на ощупь как густой кисель. Твои пальцы теперь навсегда останутся черными."
                jump choice_loop
                
            "Молча наблюдать":
                $ resonance += 5
                $ ink_level -= 5
                "Существо пульсирует в такт твоему сердцебиению. Это пугает."
                jump choice_loop
                
            "Попробовать заговорить":
                p "Кто ты?"
                s ". . . С . . . У . . . М . . . И . . ."
                $ resonance += 10
                jump choice_loop

            "Уйти (Закончить)" if resonance > 30:
                jump end_normal

label end_normal:
    "Я ухожу из леса. Но я знаю, что на моих руках остались пятна, которые не смыть ничем."
    "Резонанс остался на уровне [resonance]%. До встречи."
    return

label end_transcendence:
    scene black with flash
    "Больше нет леса. Нет меня. Есть только чернила на бесконечном белом листе."
    "МЫ СТАЛИ ОДНИМ ЦЕЛЫМ."
    return
